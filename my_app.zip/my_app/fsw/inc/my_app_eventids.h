/************************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/

/**
 * @file
 *
 * Define Sample App Events IDs
 */

#ifndef my_app_EVENTS_H
#define my_app_EVENTS_H

#define my_app_RESERVED_EID      0
#define my_app_INIT_INF_EID      1
#define my_app_CC_ERR_EID        2
#define my_app_NOOP_INF_EID      3
#define my_app_RESET_INF_EID     4
#define my_app_MID_ERR_EID       5
#define my_app_CMD_LEN_ERR_EID   6
#define my_app_PIPE_ERR_EID      7
#define my_app_VALUE_INF_EID     8
#define my_app_CR_PIPE_ERR_EID   9
#define my_app_SUB_HK_ERR_EID    10
#define my_app_SUB_CMD_ERR_EID   11
#define my_app_TABLE_REG_ERR_EID 12
#define my_app_INFO_EID          13
#endif /* my_app_EVENTS_H */
