/************************************************************************
 * NASA Docket No. GSC-18,719-1, and identified as “core Flight System: Bootes”
 *
 * Copyright (c) 2020 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/

/**
 * \file
 *   This file contains the source code for the My App Ground Command-handling functions
 */

/*
** Include Files:
*/
#include "my_app.h"
#include "my_app_cmds.h"
#include "my_app_msgids.h"
#include "my_app_eventids.h"
#include "my_app_version.h"
#include "my_app_tbl.h"
#include "my_app_utils.h"
#include "my_app_msg.h"

/* The my_lib module provides the my_Function() prototype */
#include "sample_lib.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
/*                                                                            */
/*  Purpose:                                                                  */
/*         This function is triggered in response to a task telemetry request */
/*         from the housekeeping task. This function will gather the Apps     */
/*         telemetry, packetize it and send it to the housekeeping task via   */
/*         the software bus                                                   */
/* * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * *  * *  * * * * */
CFE_Status_t my_app_SendHkCmd(const my_app_SendHkCmd_t *Msg)
{
    int i;

    /*
    ** Get command execution counters...
    */
    my_app_Data.HkTlm.Payload.CommandErrorCounter = my_app_Data.ErrCounter;
    my_app_Data.HkTlm.Payload.CommandCounter      = my_app_Data.CmdCounter;

    /*
    ** Send housekeeping telemetry packet...
    */
    CFE_SB_TimeStampMsg(CFE_MSG_PTR(my_app_Data.HkTlm.TelemetryHeader));
    CFE_SB_TransmitMsg(CFE_MSG_PTR(my_app_Data.HkTlm.TelemetryHeader), true);

    /*
    ** Manage any pending table loads, validations, etc.
    */
    for (i = 0; i < my_app_NUMBER_OF_TABLES; i++)
    {
        CFE_TBL_Manage(my_app_Data.TblHandles[i]);
    }

    return CFE_SUCCESS;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
/*                                                                            */
/* my NOOP commands                                                       */
/*                                                                            */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
CFE_Status_t my_app_NoopCmd(const my_app_NoopCmd_t *Msg)
{
    my_app_Data.CmdCounter++;

    CFE_EVS_SendEvent(my_app_NOOP_INF_EID, CFE_EVS_EventType_INFORMATION, "my: NOOP command %s",
                      my_app_VERSION);

    return CFE_SUCCESS;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
/*                                                                            */
/*  Purpose:                                                                  */
/*         This function resets all the global counter variables that are     */
/*         part of the task telemetry.                                        */
/*                                                                            */
/* * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * *  * *  * * * * */
CFE_Status_t my_app_ResetCountersCmd(const my_app_ResetCountersCmd_t *Msg)
{
    my_app_Data.CmdCounter = 0;
    my_app_Data.ErrCounter = 0;

    CFE_EVS_SendEvent(my_app_RESET_INF_EID, CFE_EVS_EventType_INFORMATION, "my: RESET command");

    return CFE_SUCCESS;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
/*                                                                            */
/*  Purpose:                                                                  */
/*         This function Process Ground Station Command                       */
/*                                                                            */
/* * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * *  * *  * * * * */
CFE_Status_t my_app_ProcessCmd(const my_app_ProcessCmd_t *Msg)
{
    CFE_Status_t               status;
    void *                     TblAddr;
    my_app_ExampleTable_t *TblPtr;
    const char *               TableName = "my_app.ExampleTable";

    /* my Use of Example Table */

    status = CFE_TBL_GetAddress(&TblAddr, my_app_Data.TblHandles[0]);

    if (status < CFE_SUCCESS)
    {
        CFE_ES_WriteToSysLog("my App: Fail to get table address: 0x%08lx", (unsigned long)status);
        return status;
    }

    TblPtr = TblAddr;
    CFE_ES_WriteToSysLog("my App: Example Table Value 1: %d  Value 2: %d", TblPtr->Int1, TblPtr->Int2);

    my_app_GetCrc(TableName);

    status = CFE_TBL_ReleaseAddress(my_app_Data.TblHandles[0]);
    if (status != CFE_SUCCESS)
    {
        CFE_ES_WriteToSysLog("my App: Fail to release table address: 0x%08lx", (unsigned long)status);
        return status;
    }

    /* Invoke a function provided by sample_app_LIB */
    SAMPLE_LIB_Function();

    return CFE_SUCCESS;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
/*                                                                            */
/* A simple example command that displays a passed-in value                   */
/*                                                                            */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/
CFE_Status_t my_app_DisplayParamCmd(const my_app_DisplayParamCmd_t *Msg)
{
    CFE_EVS_SendEvent(my_app_VALUE_INF_EID, CFE_EVS_EventType_INFORMATION,
                      "my_app: ValU32=%lu, ValI16=%d, ValStr=%s", (unsigned long)Msg->Payload.ValU32,
                      (int)Msg->Payload.ValI16, Msg->Payload.ValStr);

    return CFE_SUCCESS;
}
